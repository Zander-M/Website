********************************************************************
	ZYPOP - HTTPS://ZYPOPWEBTEMPLATES.COM
	FREE WEB TEMPLATES
********************************************************************

This is a free web template by ZyPOP (https://zypopwebtemplates.com)



1. Customizing this template
-----------------------------------------
To change the text, content, links etc. open the index.html and other HTML files in your preferred HTML editor. 

The CSS is built on the Bootstrap 4 framework. You can find the customisable scss files in the /scss folder and the original bootstrap files in the /vendor folder. 

The variables.scss file can be used to customise both default Bootstrap variables and custom variables used in this specific template. 

The core.css file can be used to customise the design of this template.

They can then be recompiled with the Bootstrap framework into styles.css using your favourite Sass compiler. 

For documentation on the Bootstrap framework see: https://getbootstrap.com/docs/4.0/getting-started/introduction/




2. Terms of use/Licenses
-----------------------------------------
This template includes the Bootstrap 4 CSS and Javascript framework. This is licensed under The MIT License: https://github.com/twbs/bootstrap/blob/master/LICENSE

Any stock photographs used in this template are from http://unsplash.com/

This web template also contains support for Font Awesome. For more information see: http://fontawesome.io/license/

The rest of the template has been released under a Creative Commons Attribution license, this means you can use the template as long as a visible link to ZyPOP (https://zypopwebtemplates.com) remains in the footer.
 
This condition can be waived by purchasing a template license for �8.00 (See 3. Template License in this document)

For more information of the license: http://creativecommons.org/licenses/by/3.0/




3. Template License
-----------------------------------------
The link back to ZyPOP (https://zypopwebtemplates.com) and any other copyright/information relating to ZyPOP (https://zypopwebtemplates.com) can be removed with the purchase of a template license. A license costs �8.00 GBP (Approx $10 USD) per domain and gives the site owner/webmaster the right to remove this information.

To purchase a license or for more information see: http://zypopwebtemplates.com/licensing




4. Other information
-----------------------------------------
Please contact us if you need more information about template licences, use of our templates or other queries -  https://zypopwebtemplates.com/contact
